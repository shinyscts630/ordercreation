package com.ewallet.product.ordercreation.service;


import com.ewallet.product.ordercreation.dto.OrderRequest;
import com.ewallet.product.ordercreation.model.Order;
import com.ewallet.product.ordercreation.model.OrderItem;
import com.ewallet.product.ordercreation.model.Payment;
import com.ewallet.product.ordercreation.model.Product;
import com.ewallet.product.ordercreation.repository.OrderRepository;
import com.ewallet.product.ordercreation.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@SLF4J
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository, ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
		this.restTemplate = new RestTemplate();
    }

    @Transactional
    public Order createOrder(OrderRequest orderRequest) {
    	//Step#1:
        Order order = new Order();
        order.setOrderDate(new Date());
        order.setOrderNumber("ORD-" + System.currentTimeMillis()); // simple unique number

        List<OrderItem> items = orderRequest.items().stream().map(itemRequest -> {
            Product product = productRepository.findById(itemRequest.productId())
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + itemRequest.productId()));

            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(product);
            orderItem.setQuantity(itemRequest.quantity());
            orderItem.setCost(product.getCost()); 
            orderItem.setOrder(order);
            return orderItem;
        }).collect(Collectors.toList());

        order.setOrderItems(items);
        //step-2:
        Payment payment= new Payment();
        payment.setOrderId(order.getOrderNumber());
        payment.setCost(order.getCost());
        
        return orderRepository.save(order);
    }
    
    private final RestTemplate restTemplate;

    public OrderService(RestTemplate restTemplate) {
        this.orderRepository = orderRepository;
		this.productRepository = productRepository;
		this.restTemplate = restTemplate;
    }
    @CircuitBreaker(name = "paymentService", fallbackMethod = "fallbackForInventory")
    public String placeOrder(String itemDetails) {
        String response = restTemplate.getForObject("http://payment-service/checkInventory", String.class);
        return "Order Placed: " + response;
    }
    
    public class OrderNotFoundException extends RuntimeException {
        public OrderNotFoundException(String message) {
            super(message);
        }
    }

    public class InvalidOrderDataException extends RuntimeException {
        public InvalidOrderDataException(String message) {
            super(message);
        }
    }
}

