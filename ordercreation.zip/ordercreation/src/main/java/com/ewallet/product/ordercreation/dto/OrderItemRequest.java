package com.ewallet.product.ordercreation.dto;

// DTO for an item within an order request
public record OrderItemRequest(Long productId, int quantity) {}


