package com.ewallet.product.ordercreation.model;


import jakarta.persistence.*; // Note the jakarta.* imports
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int productId;
    private String productName;
    private int cost;
    private int quantity;
    private int currency;
    private int merchantId;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getCurrency() {
		return currency;
	}
	public void setCurrency(int currency) {
		this.currency = currency;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public Product(int productId, String productName, int cost, int quantity, int currency, int merchantId) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.cost = cost;
		this.quantity = quantity;
		this.currency = currency;
		this.merchantId = merchantId;
	}
    
    
}
// Order and OrderItem entities remain largely the same as in the initial prompt, 
// just ensure all imports use 'jakarta.persistence.*'.
