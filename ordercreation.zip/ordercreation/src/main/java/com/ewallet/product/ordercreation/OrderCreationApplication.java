package com.ewallet.product.ordercreation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderCreationApplication.class, args);
	}

}
