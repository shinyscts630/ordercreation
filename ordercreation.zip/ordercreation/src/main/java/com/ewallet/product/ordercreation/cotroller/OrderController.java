package com.ewallet.product.ordercreation.cotroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ewallet.product.ordercreation.dto.OrderRequest;
import com.ewallet.product.ordercreation.model.Order;
import com.ewallet.product.ordercreation.service.OrderService;

@RestController
@RequestMapping("/api/ordercreation")
public class OrderController {

	   @Autowired
       private OrderService orderService;

       @PostMapping
       public ResponseEntity<Order> createOrder(@RequestBody OrderRequest orderRequest) {
           Order newOrder = orderService.createOrder(orderRequest);
           return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
       }
   }