package com.ewallet.product.ordercreation.dto;

import java.util.List;

//DTO for the entire order creation request
public record OrderRequest(String customerId, List<OrderItemRequest> items) {}