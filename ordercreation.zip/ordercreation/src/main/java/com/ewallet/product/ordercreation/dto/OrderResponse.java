package com.ewallet.product.ordercreation.dto;


//DTO for the response after placing an order
public record OrderResponse(int transctionId, String status) {}