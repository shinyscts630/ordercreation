package com.ewallet.product.ordercreation.model;

public class Payment {
	private String orderId;
	private int cost;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public Payment(String orderId, int cost) {
		super();
		this.orderId = orderId;
		this.cost = cost;
	}
	public Payment() {
		super();
	}
	
	
}
