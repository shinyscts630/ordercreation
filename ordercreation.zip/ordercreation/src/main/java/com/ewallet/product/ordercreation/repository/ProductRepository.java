package com.ewallet.product.ordercreation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ewallet.product.ordercreation.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

}
